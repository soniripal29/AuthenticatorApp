
function sendAuthData()
{

    let currentUser = document.getElementById('username').value;
    let password = document.getElementById('password').value;

    if (currentUser==="admin" && password==="admin")
    {
        alert("Login Successful");
    }
    else
    {
        alert("Use admin / admin for id and pwd")
    }

   //need to send both the variables to the login api 
}
export default sendAuthData;