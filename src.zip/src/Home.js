import logo from './logo.svg';
import sendAuthData from './LoginData';

function Home(){
    return(
        <form className='Form'>
        <img src={logo} className="App-logo" alt="logo" /><br></br><br></br><br></br><br></br><br></br><br></br>
        <h2>&nbsp;User Login</h2>
        <div className='Username'>
        <input type="text" placeholder="Username" id="username"></input>
        </div>
        <div className='password'>
        <input type="password" placeholder="Password" id="password"></input> <br></br><br></br>
        </div>
        <button id="btn" type="submit" onClick={sendAuthData}>Login</button>
        &nbsp; &nbsp;
        <br></br><p>Dont have an account?</p>
        <a href="Register.html">
             SignUp
         </a>
        </form>
    );
}

export default Home;